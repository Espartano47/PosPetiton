-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: rrhh
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `usuarios_con_empresaa`
--

DROP TABLE IF EXISTS `usuarios_con_empresaa`;
/*!50001 DROP VIEW IF EXISTS `usuarios_con_empresaa`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `usuarios_con_empresaa` AS SELECT 
 1 AS `id`,
 1 AS `Nombre`,
 1 AS `password`,
 1 AS `username`,
 1 AS `Correo`,
 1 AS `role`,
 1 AS `estado`,
 1 AS `foto`,
 1 AS `created`,
 1 AS `LastLogin`,
 1 AS `createdByName`,
 1 AS `createdById`,
 1 AS `empresaId`,
 1 AS `forcePasswordChange`,
 1 AS `NombreEmpresa`,
 1 AS `Pais`,
 1 AS `permisos`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `usuarios_con_empresa`
--

DROP TABLE IF EXISTS `usuarios_con_empresa`;
/*!50001 DROP VIEW IF EXISTS `usuarios_con_empresa`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `usuarios_con_empresa` AS SELECT 
 1 AS `id`,
 1 AS `Nombre`,
 1 AS `password`,
 1 AS `username`,
 1 AS `Correo`,
 1 AS `role`,
 1 AS `estado`,
 1 AS `foto`,
 1 AS `created`,
 1 AS `LastLogin`,
 1 AS `createdByName`,
 1 AS `createdById`,
 1 AS `empresaId`,
 1 AS `forcePasswordChange`,
 1 AS `NombreEmpresa`,
 1 AS `Pais`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `usuarios_con_empresaa`
--

/*!50001 DROP VIEW IF EXISTS `usuarios_con_empresaa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usuarios_con_empresaa` AS select `u`.`id` AS `id`,`u`.`Nombre` AS `Nombre`,`u`.`password` AS `password`,`u`.`username` AS `username`,`u`.`Correo` AS `Correo`,`u`.`role` AS `role`,`u`.`estado` AS `estado`,`u`.`foto` AS `foto`,`u`.`created` AS `created`,`u`.`LastLogin` AS `LastLogin`,`u`.`createdByName` AS `createdByName`,`u`.`createdById` AS `createdById`,`u`.`empresaId` AS `empresaId`,`u`.`forcePasswordChange` AS `forcePasswordChange`,`e`.`Nombre` AS `NombreEmpresa`,`e`.`Pais` AS `Pais`,group_concat(`p`.`nombre` order by `p`.`nombre` ASC separator ',') AS `permisos` from (((`usuarios` `u` left join `empresas` `e` on((`u`.`empresaId` = `e`.`idnew_table`))) left join `usuarios_permisos` `up` on((`up`.`usuario_id` = `u`.`id`))) left join `permisos` `p` on((`p`.`id` = `up`.`permiso_id`))) group by `u`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usuarios_con_empresa`
--

/*!50001 DROP VIEW IF EXISTS `usuarios_con_empresa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usuarios_con_empresa` AS select `u`.`id` AS `id`,`u`.`Nombre` AS `Nombre`,`u`.`password` AS `password`,`u`.`username` AS `username`,`u`.`Correo` AS `Correo`,`u`.`role` AS `role`,`u`.`estado` AS `estado`,`u`.`foto` AS `foto`,`u`.`created` AS `created`,`u`.`LastLogin` AS `LastLogin`,`u`.`createdByName` AS `createdByName`,`u`.`createdById` AS `createdById`,`u`.`empresaId` AS `empresaId`,`u`.`forcePasswordChange` AS `forcePasswordChange`,`e`.`Nombre` AS `NombreEmpresa`,`e`.`Pais` AS `Pais` from (`usuarios` `u` left join `empresas` `e` on((`u`.`empresaId` = `e`.`idnew_table`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-29  7:18:17
