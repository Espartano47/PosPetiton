-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: rrhh
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `estado` enum('Activo','Inactivo') DEFAULT 'Activo',
  `foto` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `createdByName` varchar(255) NOT NULL,
  `createdById` int NOT NULL,
  `empresaId` int NOT NULL,
  `Correo` varchar(255) DEFAULT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `LastLogin` datetime DEFAULT NULL,
  `forcePasswordChange` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'juan','$2b$12$zuHNxDvANw62.LC058jLGemNNsEqmw7YGsjnGV08lA4DkuA6xyFAe','user','Activo',NULL,'2026-01-23 15:03:18','',0,2,NULL,NULL,NULL,1),(2,'yermy','$2b$12$dJVz/ZKH2Obzhe90O24Lze1zmt7tj9Qdp4H6p4IbZz/MkWxxsKmr2','user','Activo',NULL,'2026-01-23 15:03:18','',0,2,'Yermyvaldezpolanco@gmail.com','Yermy Valdez Polanco','2026-01-29 11:07:24',0),(3,'yvaldez','$2b$12$mXcel8nCyebJIDLyJoUyXuXY/6ShPnE4DeYzu2jv228CP5w9yzBZu','admin','Activo','/uploads/empleados/4850ff2e-087d-47ad-a4de-4ddd05b3b05e.png','2026-01-28 16:17:35','yermy',2,2,'yermy@email.com','Yermy Valdez',NULL,1),(5,'yevaldez','$2b$12$C9cCTw0RafoYpqbdj1QjGOuW4Vr7vZMoLFHNEOkriEq/q7AOIkENW','admin','Activo','/uploads/empleados/cc8aa337-411d-499d-9f5a-191bf56388dd.png','2026-01-28 16:20:34','yermy',2,2,'yermy@email.com','Yermy Valdez','2026-01-28 22:31:30',1);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-29  7:18:15
