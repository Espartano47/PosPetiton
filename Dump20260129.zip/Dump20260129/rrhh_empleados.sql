-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: rrhh
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `puesto` varchar(100) DEFAULT NULL,
  `salario` decimal(10,2) DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `estado` enum('Activo','Inactivo') DEFAULT 'Activo',
  `foto` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `createdByName` varchar(255) NOT NULL,
  `createdById` int NOT NULL,
  `empresaId` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,'Juan Pérez','IT','Desarrollador Backend',75000.00,'2022-01-10','Activo',NULL,'2026-01-23 15:04:07','',0,0),(2,'María Gómez','RRHH','Analista de RRHH',55000.00,'2021-05-15','Activo',NULL,'2026-01-23 15:04:07','',0,0),(3,'Carlos Rodríguez','Finanzas','Contador',60000.00,'2020-08-01','Activo',NULL,'2026-01-23 15:04:07','',0,0),(4,'Ana Martínez','Marketing','Diseñadora Gráfica',50000.00,'2023-03-20','Activo',NULL,'2026-01-23 15:04:07','',0,0),(5,'Pedro Sánchez','Producción','Supervisor',58000.00,'2019-11-05','Inactivo',NULL,'2026-01-23 15:04:07','',0,0),(6,'Juan Pérez','IT','Backend Developer',45000.00,'2024-01-15','Activo',NULL,'2026-01-23 15:04:07','',0,0),(7,'Yermy Valdez Polanco','IT','Backend Developer',45000.00,'2024-01-15','Activo',NULL,'2026-01-23 15:04:07','',0,0),(8,'Yermy Valdez Polanco','IT','Backend Developer',45000.00,'2024-01-15','Activo',NULL,'2026-01-23 15:04:07','',0,0),(9,'Yermy Valdez Polanco','IT','Backend Developer',45000.00,'2024-01-15','Activo',NULL,'2026-01-23 15:04:07','',0,0),(10,'Yermy Valdez Polanco','IT','Backend Developer',45000.00,'2024-01-15','Activo',NULL,'2026-01-23 15:04:07','',0,0),(11,'Kendy Baez','IT','Tech Support',74111.00,'2026-01-14','Activo',NULL,'2026-01-23 15:04:07','',0,0),(12,'adwd','wdadwdadwa','dawdawdawd',2134324.00,'2026-01-22','Activo','uploads/empleados\\68eb7ad8-8a0f-4b75-b45b-d90af63b82a5.png','2026-01-23 15:04:07','',0,0),(13,'adwd','wdadwdadwa','dawdawdawd',2134324.00,'2026-01-22','Activo','uploads/empleados\\966c9fd0-6399-4081-a626-7d50c6dd8d27.png','2026-01-23 15:04:07','',0,0),(14,'adwd','wdadwdadwa','dawdawdawd',2134324.00,'2026-01-22','Activo','uploads/empleados\\322f58bf-02a9-4c3a-98d9-ee6e42f01683.png','2026-01-23 15:04:07','',0,0),(15,'asdasds','asdasdas','dasdd',1234324.00,'2026-01-22','Activo','/uploads/empleados/c50dfc37-6e1c-46d8-a8d3-e1fb33a79a02.png','2026-01-23 15:04:07','',0,0),(16,'Yermy Valdez','awdawd','awdawd',12321321.00,'2026-01-21','Activo','/uploads/empleados/b18b8ff4-301d-4de7-94b9-d97112991273.png','2026-01-23 15:04:07','',0,0),(17,'Kuawd','awdawd','awdawd',1313.00,'2026-01-22','Activo','/uploads/empleados/a4b00d68-bdb5-49b4-9580-fb6165bb5a3b.png','2026-01-23 15:22:49','yermy',2,0),(18,'test','test','test',214.00,'2026-01-29','Activo','/uploads/empleados/65464401-8bb8-4841-81d1-b48ccf9146f9.png','2026-01-23 16:32:39','yermy',2,2);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-29  7:18:16
